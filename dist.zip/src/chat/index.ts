// Punto de entrada para inicializar el chat
export { initChatWidget } from './ui';
